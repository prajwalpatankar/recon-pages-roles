from django.contrib import admin
from .models import *

# Register your models here.
admin.site.register(Tbl_Role_Mst)
admin.site.register(tbl_login_mst)
admin.site.register(Tbl_Country_Mst)
admin.site.register(Tbl_State_Mst)
admin.site.register(Tbl_City_Mst)
admin.site.register(tbl_location_mst)
admin.site.register(tbl_term_mst)
admin.site.register(tbl_company_mst)
admin.site.register(tbl_master)
admin.site.register(Tbl_Uom_Mst)
admin.site.register(tbl_reason_mst) 
admin.site.register(tbl_channel_mst)
admin.site.register(tbl_source_details)
admin.site.register(tbl_source_mst)
admin.site.register(Tbl_Currency_Mst)


